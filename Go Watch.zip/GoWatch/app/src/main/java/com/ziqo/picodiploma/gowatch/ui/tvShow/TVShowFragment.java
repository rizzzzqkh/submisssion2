package com.ziqo.picodiploma.gowatch.ui.tvShow;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ziqo.picodiploma.gowatch.R;

import java.util.ArrayList;

public class TVShowFragment extends Fragment {

    private RecyclerView rvTVShow;
    private ArrayList<TVShow> list = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_tv_show, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rvTVShow = getActivity().findViewById(R.id.rv_tv_show);
        rvTVShow.setHasFixedSize(true);

        list.addAll(getListData());
        showRecyclerList();
    }

    public ArrayList<TVShow> getListData() {
        String[] dataTitle = getResources().getStringArray(R.array.data_name_tvshow);
        String[] dataDescription = getResources().getStringArray(R.array.data_detail_tvshow);
        TypedArray dataPoster = getResources().obtainTypedArray(R.array.data_photo_tvshow);

        ArrayList<TVShow> listTVShow = new ArrayList<>();
        for (int i = 0; i < dataTitle.length; i++) {
            TVShow tvShow = new TVShow();
            tvShow.setTitle(dataTitle[i]);
            tvShow.setDescription(dataDescription[i]);
            tvShow.setPoster(dataPoster.getResourceId(i, -1));

            listTVShow.add(tvShow);
        }
        return listTVShow;
    }

    private void showRecyclerList() {
        rvTVShow.setLayoutManager(new LinearLayoutManager(getContext()));
        TVShowAdapter tvShowAdapter = new TVShowAdapter(list);
        rvTVShow.setAdapter(tvShowAdapter);
    }
}