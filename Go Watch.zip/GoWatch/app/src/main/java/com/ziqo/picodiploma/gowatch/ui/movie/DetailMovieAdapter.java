package com.ziqo.picodiploma.gowatch.ui.movie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ziqo.picodiploma.gowatch.R;

import org.w3c.dom.Text;

public class DetailMovieAdapter extends AppCompatActivity {

    public final static String EXTRA_MOVIE = "extra_movie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie_adapter);

        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvDescription = findViewById(R.id.tv_description);
        ImageView imgPoster = findViewById(R.id.img_poster);

        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);


        tvTitle.setText(movie.getTitle());
        tvDescription.setText(movie.getDescription());
        Glide.with(this)
                .load(movie.getPoster())
                .into(imgPoster);
    }


}
